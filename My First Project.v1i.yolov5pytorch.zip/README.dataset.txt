# My First Project > 2025-03-22 11:56am
https://universe.roboflow.com/aniket-tare-qucv3/my-first-project-mrqnz

Provided by a Roboflow user
License: CC BY 4.0

